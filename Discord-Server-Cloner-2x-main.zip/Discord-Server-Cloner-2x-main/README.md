# Discord Server Cloner 2x

*Support the project by leaving a :star:*

---

## Overview
This project was made to make your life easier, instead of spending hours trying to make your server as beautiful as possible you can simply clone a server with this tool

**More information:** [Cloner Website](https://cloner-one.vercel.app/)

## How to use? 
```typescript
$ pnpm i
# or
$ npm i
# or
$ yarn add
```
**Examples with tsx**
```typescript
$ pnpm i -g tsx
# or
$ npm i -g tsx
```

```typescript
$ tsx .
```
**You can also use [codesandbox](https://codesandbox.io/dashboard/recent) to start the cloner**

----

### Thank you for your support!
